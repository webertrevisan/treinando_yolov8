# ESCALIBUR > 2025-05-02 1:20pm
https://universe.roboflow.com/weber-cy2ec/escalibur

Provided by a Roboflow user
License: CC BY 4.0

