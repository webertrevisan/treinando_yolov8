# TEETH > 2025-05-01 2:10pm
https://universe.roboflow.com/weber-cy2ec/teeth-pydgz

Provided by a Roboflow user
License: CC BY 4.0

